import server

app = server.createApp()
app.run()